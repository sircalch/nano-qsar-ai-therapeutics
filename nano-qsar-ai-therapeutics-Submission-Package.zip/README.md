# nano-qsar-ai-therapeutics

## Explainable AI and Quantum-Guided QSAR/QSPR Modeling of Triple-Negative Breast Cancer Therapeutics Conjugated to Functionalized Boron Nitride Nanocages

### 🔬 Project Overview
This repository contains the complete computational workflow, quantum chemical modeling, molecular docking simulations, explainable machine learning pipelines (XAI via SHAP), and publication manuscript investigating **Boron Nitride Nanocages ($B_{36}N_{36}$ / $B_{36}N_{36}\text{-COOH}$)** as advanced nanocarriers for **42 Triple-Negative Breast Cancer (TNBC) therapeutics** targeting **PARP1**.

### 📁 Directory Layout
```text
nano-qsar-ai-therapeutics/
├── README.md                          # Project documentation and reproduction guide
├── data/
│   ├── raw/                           # Curated TNBC drug library (CSV & JSON)
│   ├── processed/                     # Computed QSAR & quantum electronic datasets
│   └── splits/                        # 80/20 Train and External Validation partitions
├── src/
│   ├── descriptors/                   # RDKit/Mordred 2D/3D descriptor extraction
│   ├── quantum/                       # DFTB3 / Conceptual DFT and HSAB reactivity engine
│   ├── docking/                       # AutoDock Vina simulation & binding pocket mapper
│   ├── ml_models/                     # ExtraTrees, XGBoost, MLR training & SHAP interpretability
│   └── visualization/                 # 300+ DPI publication figure generation scripts
├── results/
│   ├── models/                        # Benchmark metrics JSON and fitted parameters
│   └── xai/                           # SHAP feature importance rankings
├── figures/                           # High-resolution figures (Fig 1 to Fig 5)
└── manuscript/
    ├── manuscript.md                  # Complete drafted article in Markdown
    ├── manuscript.tex                 # Full LaTeX manuscript formatted for publication
    ├── references.bib                 # BibTeX citation database
    └── supplementary_info.md          # Supplementary Tables (S1–S5)
```

### 🚀 Key Scientific Findings
1. **Target Affinity Amplification**: Drug complexation with $B_{36}N_{36}$ and $B_{36}N_{36}\text{-COOH}$ significantly increases PARP1 binding scores from $-10.14$ kcal/mol to $-13.45$ kcal/mol and $-14.01$ kcal/mol, respectively.
2. **Spatial Pocket Relocation**: Isolated drugs bind deeply within the catalytic triad (Gly863, Tyr907, Glu988), whereas BN nanocage complexes relocate to outer regulatory clefts and polar surface grooves.
3. **High ML Predictive Performance**: ExtraTrees regressors achieve test MAPEs of $3.14\% - 4.54\%$ with $R^2 > 0.81$.
4. **Explainable AI (SHAP)**: Identifies nanocarrier adsorption energy ($\Delta E_{ads}$), aromatic ring count, polar surface area (PSA), and electronic chemical potential ($\mu$) as primary biophysical determinants.
5. **Closed-Form QSAR Equations**: Exportable Multiple Linear Regression (MLR) mathematical equations are formulated for direct prediction.

### 💻 How to Reproduce
```bash
# 1. Curate drug library and compute descriptors
python src/descriptors/curate_dataset.py
python src/descriptors/compute_descriptors.py

# 2. Compute quantum HSAB parameters
python src/quantum/quantum_hsab_engine.py

# 3. Simulate and analyze molecular docking
python src/docking/docking_engine.py

# 4. Train AI models & extract SHAP values
python src/ml_models/train_qsar_models.py

# 5. Generate publication figures
python src/visualization/generate_publication_figures.py
python src/visualization/generate_fig2_quantum_schematics.py
```
